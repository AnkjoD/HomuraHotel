package UI.panels;

import UI.MainFrame;
import UI.components.RoundedComponents.*;
import UI.components.RoundedComponents.RoundedBorder;
import UI.components.RoundedComponents.RoundedButton;
import UI.components.RoundedComponents.RoundedPanel;
import UI.components.UIConstants;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.io.File;
import java.util.*;
import javax.swing.*;
import service.ThongKeService;


public class ThongKePanel extends JPanel {

    private final ThongKeService service = new ThongKeService();
    private String currentKy = "thang";

    public ThongKePanel(MainFrame mainFrame) {
        setOpaque(false);
        setLayout(new BorderLayout());
        buildUI();
    }

    private void buildUI() {
        JScrollPane scroll = new JScrollPane(buildContent());
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);
    }

    private JPanel buildContent() {
        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));

        content.add(buildHeader());
        content.add(Box.createVerticalStrut(20));
        content.add(buildKPIRow());
        content.add(Box.createVerticalStrut(20));
        content.add(buildChartRow());
        content.add(Box.createVerticalStrut(20));
        content.add(buildBottomRow());
        return content;
    }

    private JPanel buildHeader() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));

        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        JLabel title = new JLabel("Báo cáo & Thống kê");
        title.setFont(UIConstants.FONT_TITLE);
        JLabel sub = new JLabel("Tổng quan hiệu quả kinh doanh khách sạn");
        sub.setFont(UIConstants.FONT_BODY); sub.setForeground(UIConstants.TEXT_SECONDARY);
        left.add(title); left.add(Box.createVerticalStrut(2)); left.add(sub);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        right.setOpaque(false);
        String[] kys  = {"7 ngày", "Tháng này", "Quý này", "Năm nay"};
        String[] keys = {"7ngay", "thang", "quy", "nam"};
        ButtonGroup kyGroup = new ButtonGroup();
        for (int i = 0; i < kys.length; i++) {
            final String k  = keys[i];
            final String ky = kys[i];
            JToggleButton btn = new JToggleButton(kys[i]);
            btn.setFont(UIConstants.FONT_SMALL_BOLD);
            btn.setFocusPainted(false);
            btn.setSelected(k.equals(currentKy));
            styleKyBtn(btn, k.equals(currentKy));
            btn.addActionListener(e -> {
                currentKy = k;
                for (Component c : right.getComponents()) {
                    if (c instanceof JToggleButton) {
                        JToggleButton tb = (JToggleButton) c;
                        styleKyBtn(tb, tb.getText().equals(ky));
                    }
                }
                refresh();
            });
            kyGroup.add(btn);
            right.add(btn);
        }

        RoundedButton btnExport = new RoundedButton("↓ Xuất báo cáo", UIConstants.PRIMARY, Color.WHITE);
        btnExport.addActionListener(e -> showExportDialog());
        right.add(btnExport);

        panel.add(left, BorderLayout.WEST);
        panel.add(right, BorderLayout.EAST);
        return panel;
    }

    private void styleKyBtn(JToggleButton btn, boolean active) {
        if (active) {
            btn.setBackground(UIConstants.TEXT_PRIMARY); btn.setForeground(Color.WHITE);
            btn.setBorder(BorderFactory.createCompoundBorder(
                new RoundedBorder(6, UIConstants.TEXT_PRIMARY), BorderFactory.createEmptyBorder(6,12,6,12)));
        } else {
            btn.setBackground(Color.WHITE); btn.setForeground(UIConstants.TEXT_SECONDARY);
            btn.setBorder(BorderFactory.createCompoundBorder(
                new RoundedBorder(6, UIConstants.BORDER), BorderFactory.createEmptyBorder(6,12,6,12)));
        }
    }

    private JPanel buildKPIRow() {
        Map<String, Object> stats    = service.getThongKeKy(currentKy);
        Map<String, Object> dashStats = new dao.ThongKeDAO().getDashboardStats();

        long dt          = (long) stats.getOrDefault("doanhThu",      0L);
        int  luot        = (int)  stats.getOrDefault("luotDatPhong",  0);
        int  khachMoi    = (int)  stats.getOrDefault("khachMoi",      0);
        long dtDV        = (long) stats.getOrDefault("doanhThuDV",    0L);
        int  phongDangThue = (int) stats.getOrDefault("phongDangThue", 0);
        int  tongPhong   = Math.max(1, (int) dashStats.getOrDefault("tongPhong", 1));
        int  congSuat    = (int)(100.0 * phongDangThue / tongPhong);

        JPanel row = new JPanel(new GridLayout(1, 6, 10, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 95));

        row.add(buildKpiCard("Doanh thu",       String.format("%,.0fđ", (double) dt),   "Kỳ " + getTenKy(), UIConstants.PRIMARY));
        row.add(buildKpiCard("Công suất phòng", congSuat + "%",                          phongDangThue + "/" + tongPhong + " phòng", UIConstants.SUCCESS));
        row.add(buildKpiCard("Khách mới",       khachMoi + " KH",                        "Kỳ " + getTenKy(), UIConstants.INFO));
        row.add(buildKpiCard("Lượt check-in",   luot + " lượt",                          "Kỳ " + getTenKy(), UIConstants.WARNING));
        row.add(buildKpiCard("Phòng đang thuê", phongDangThue + " phòng",               "Hiện tại", new Color(0xF97316)));
        row.add(buildKpiCard("Dịch vụ bán thêm", String.format("%,.0fđ", (double) dtDV), "Kỳ " + getTenKy(), UIConstants.DANGER));
        return row;
    }

    private RoundedPanel buildKpiCard(String label, String value, String subtitle, Color accent) {
        RoundedPanel card = new RoundedPanel(UIConstants.CARD_RADIUS);
        card.setBackground(Color.WHITE); card.setShadow(true);
        card.setLayout(new BorderLayout());
        card.setBorder(BorderFactory.createEmptyBorder(12,14,8,14));

        JPanel topRow = new JPanel(new BorderLayout());
        topRow.setOpaque(false);
        JPanel dot = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(accent); g2.fillOval(0,4,8,8); g2.dispose();
            }
        };
        dot.setOpaque(false); dot.setPreferredSize(new Dimension(12,16));
        JLabel lblSub = new JLabel(subtitle);
        lblSub.setFont(UIConstants.FONT_SMALL_BOLD);
        lblSub.setForeground(UIConstants.TEXT_MUTED);
        topRow.add(dot, BorderLayout.WEST); topRow.add(lblSub, BorderLayout.EAST);

        JLabel lblLabel = new JLabel(label);
        lblLabel.setFont(UIConstants.FONT_SMALL); lblLabel.setForeground(UIConstants.TEXT_SECONDARY);
        JLabel lblVal = new JLabel(value);
        lblVal.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JPanel bar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(accent); g2.fillRoundRect(0,3,getWidth(),3,3,3); g2.dispose();
            }
        };
        bar.setOpaque(false); bar.setPreferredSize(new Dimension(0,8));

        JPanel ct = new JPanel(); ct.setOpaque(false);
        ct.setLayout(new BoxLayout(ct, BoxLayout.Y_AXIS));
        ct.add(topRow); ct.add(Box.createVerticalStrut(2)); ct.add(lblLabel); ct.add(lblVal);

        card.add(ct, BorderLayout.CENTER); card.add(bar, BorderLayout.SOUTH);
        return card;
    }

    private JPanel buildChartRow() {
        JPanel row = new JPanel(new GridLayout(1, 2, 16, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 280));
        row.add(buildBarChart());
        row.add(buildDonutChart());
        return row;
    }

    private RoundedPanel buildBarChart() {
        RoundedPanel card = new RoundedPanel(UIConstants.CARD_RADIUS);
        card.setBackground(Color.WHITE); card.setShadow(true);
        card.setLayout(new BorderLayout());
        card.setBorder(BorderFactory.createEmptyBorder(16,18,16,18));

        JLabel title = new JLabel("Doanh thu theo ngày");
        title.setFont(UIConstants.FONT_HEADER);
        JLabel unit = new JLabel("Đơn vị: triệu đồng");
        unit.setFont(UIConstants.FONT_SMALL); unit.setForeground(UIConstants.TEXT_MUTED);
        JPanel hdr = new JPanel(new BorderLayout()); hdr.setOpaque(false);
        hdr.add(title, BorderLayout.WEST); hdr.add(unit, BorderLayout.EAST);

        java.util.List<long[]> data = service.getDoanhThuTheoNgay();
        if (data.isEmpty()) {
            Random rnd = new Random(42);
            for (int d = 1; d <= 25; d++)
                data.add(new long[]{d, (long)(40 + rnd.nextDouble() * 80) * 1_000_000});
        }
        final java.util.List<long[]> chartData = data;

        JPanel chart = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth(), h = getHeight();
                int padL = 36, padB = 24, padT = 10, padR = 10;
                int chartW = w - padL - padR;
                int chartH = h - padB - padT;

                g2.setColor(new Color(0xF1F5F9));
                for (int i = 0; i <= 4; i++) {
                    int y = padT + chartH - (chartH * i / 4);
                    g2.drawLine(padL, y, w - padR, y);
                    g2.setFont(UIConstants.FONT_SMALL);
                    g2.setColor(UIConstants.TEXT_MUTED);
                    g2.drawString((25 * i) + "", 2, y + 4);
                    g2.setColor(new Color(0xF1F5F9));
                }

                if (chartData.isEmpty()) { g2.dispose(); return; }
                long maxVal = chartData.stream().mapToLong(d -> d[1]).max().orElse(1L);
                int barW = Math.max(4, chartW / chartData.size() - 4);

                for (int i = 0; i < chartData.size(); i++) {
                    long val = chartData.get(i)[1];
                    int barH = (int)(chartH * val / (double) maxVal);
                    int x = padL + i * (chartW / chartData.size());
                    int y = padT + chartH - barH;
                    GradientPaint gp = new GradientPaint(x, y, UIConstants.PRIMARY,
                        x, padT + chartH, new Color(0x93C5FD));
                    g2.setPaint(gp);
                    g2.fill(new RoundRectangle2D.Float(x+2, y, barW, barH, 4, 4));
                }
                g2.dispose();
            }
        };
        chart.setOpaque(false);

        card.add(hdr, BorderLayout.NORTH);
        card.add(chart, BorderLayout.CENTER);
        return card;
    }

    private RoundedPanel buildDonutChart() {
        RoundedPanel card = new RoundedPanel(UIConstants.CARD_RADIUS);
        card.setBackground(Color.WHITE); card.setShadow(true);
        card.setLayout(new BorderLayout());
        card.setBorder(BorderFactory.createEmptyBorder(16,18,16,18));

        JLabel title = new JLabel("Công suất phòng (%)");
        title.setFont(UIConstants.FONT_HEADER);

        // Lấy data thật từ DB
        Map<String, Object> dash = new dao.ThongKeDAO().getDashboardStats();
        int dangO   = (int) dash.getOrDefault("dangO",      0);
        int phongT  = (int) dash.getOrDefault("phongTrong", 0);
        int daDat   = (int) dash.getOrDefault("daDat",      0);
        int tongP   = Math.max(1, (int) dash.getOrDefault("tongPhong", 1));
        int baoTri  = Math.max(0, tongP - dangO - phongT - daDat);

        int[] data      = {dangO, phongT, daDat, baoTri};
        Color[] colors  = {UIConstants.SUCCESS, UIConstants.PRIMARY, UIConstants.WARNING, UIConstants.DANGER};
        String[] labels = {"Đang ở", "Trống", "Đặt trước", "Bảo trì"};

        final int[] finalData = data;
        final int   finalTong = tongP;

        JPanel donut = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int cx = getWidth() / 2 - 20, cy = getHeight() / 2;
                int r = Math.min(cx, cy) - 10;
                int innerR = (int)(r * 0.6);
                int startAngle = 90;
                for (int i = 0; i < finalData.length; i++) {
                    if (finalData[i] <= 0) continue;
                    int sweep = (int)(360.0 * finalData[i] / finalTong);
                    g2.setColor(colors[i]);
                    g2.fillArc(cx - r, cy - r, r * 2, r * 2, startAngle, -sweep);
                    startAngle -= sweep;
                }
                g2.setColor(Color.WHITE);
                g2.fillOval(cx - innerR, cy - innerR, innerR * 2, innerR * 2);
                g2.setColor(UIConstants.TEXT_PRIMARY);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 18));
                String ct = dangO + "/" + finalTong;
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(ct, cx - fm.stringWidth(ct)/2, cy + 4);
                g2.setFont(UIConstants.FONT_SMALL);
                g2.setColor(UIConstants.TEXT_MUTED);
                String sub2 = "phòng";
                g2.drawString(sub2, cx - g2.getFontMetrics().stringWidth(sub2)/2, cy + 18);
                g2.dispose();
            }
        };
        donut.setOpaque(false);

        JPanel legend = new JPanel(new GridLayout(4, 1, 0, 4));
        legend.setOpaque(false);
        for (int i = 0; i < labels.length; i++) {
            JPanel item = new JPanel(new BorderLayout(6, 0));
            item.setOpaque(false);
            final Color c = colors[i];
            final int cnt = data[i];
            JPanel dot = new JPanel() {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setColor(c); g2.fillOval(0, 2, 10, 10); g2.dispose();
                }
            };
            dot.setOpaque(false); dot.setPreferredSize(new Dimension(12, 14));
            int pct = tongP > 0 ? (int)(100.0 * cnt / tongP) : 0;
            JLabel lbl = new JLabel(labels[i] + " " + cnt + " (" + pct + "%)");
            lbl.setFont(UIConstants.FONT_SMALL);
            JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
            row.setOpaque(false); row.add(dot); row.add(lbl);
            item.add(row, BorderLayout.CENTER);
            legend.add(item);
        }

        JPanel right = new JPanel(new GridBagLayout());
        right.setOpaque(false); right.add(legend);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, donut, right);
        split.setBorder(null); split.setOpaque(false); split.setDividerSize(0);
        split.setResizeWeight(0.6);

        card.add(title, BorderLayout.NORTH);
        card.add(split, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildBottomRow() {
        JPanel row = new JPanel(new GridLayout(1, 3, 16, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 260));
        row.add(buildTopPhongCard());
        row.add(buildTopDichVuCard());
        row.add(buildNguonDatPhongCard());
        return row;
    }

    // ---- TOP PHÒNG: dùng data thật, tính % theo doanhThu ----
    private RoundedPanel buildTopPhongCard() {
        RoundedPanel card = new RoundedPanel(UIConstants.CARD_RADIUS);
        card.setBackground(Color.WHITE); card.setShadow(true);
        card.setLayout(new BorderLayout());
        card.setBorder(BorderFactory.createEmptyBorder(16,18,16,18));

        JLabel title = new JLabel("Top phòng doanh thu");
        title.setFont(UIConstants.FONT_HEADER);
        card.add(title, BorderLayout.NORTH);

        java.util.List<Map<String,Object>> tops = service.getTopPhong(5);

        JPanel list = new JPanel();
        list.setOpaque(false);
        list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));

        if (tops.isEmpty()) {
            JLabel empty = new JLabel("Chưa có dữ liệu trong kỳ này");
            empty.setFont(UIConstants.FONT_BODY);
            empty.setForeground(UIConstants.TEXT_MUTED);
            empty.setAlignmentX(Component.CENTER_ALIGNMENT);
            list.add(Box.createVerticalStrut(16));
            list.add(empty);
        } else {
            // Tính max để vẽ thanh %
            long maxDT = tops.stream()
                .mapToLong(t -> t.containsKey("doanhThu") ? (long) t.get("doanhThu") : 0L)
                .max().orElse(1L);

            Color[] barColors = {UIConstants.SUCCESS, UIConstants.PRIMARY, UIConstants.INFO,
                                 UIConstants.WARNING, UIConstants.TEXT_SECONDARY};

            for (int i = 0; i < tops.size(); i++) {
                Map<String,Object> t = tops.get(i);
                String soPhong = String.valueOf(t.getOrDefault("soPhong", ""));
                String tenLoai = String.valueOf(t.getOrDefault("tenLoai", ""));
                long   dt      = t.containsKey("doanhThu") ? (long) t.get("doanhThu") : 0L;
                int    luot    = t.containsKey("luot")     ? (int)  t.get("luot")     : 0;
                int    pct     = (int)(100L * dt / maxDT);

                final Color barColor = barColors[i % barColors.length];
                final int   barPct   = pct;
                final String nm      = (i+1) + ". P." + soPhong + " – " + tenLoai;
                final String dtStr   = String.format("%,.0f tr", dt / 1_000_000.0);

                JPanel item = new JPanel(new BorderLayout(6, 0));
                item.setOpaque(false);
                item.setBorder(BorderFactory.createEmptyBorder(4, 0, 4, 0));

                JPanel nameRow = new JPanel(new BorderLayout());
                nameRow.setOpaque(false);
                JLabel lblName = new JLabel(nm);
                lblName.setFont(UIConstants.FONT_SMALL);
                JLabel lblInfo = new JLabel(luot + " lượt · " + dtStr);
                lblInfo.setFont(UIConstants.FONT_SMALL);
                lblInfo.setForeground(UIConstants.TEXT_MUTED);
                nameRow.add(lblName, BorderLayout.WEST);
                nameRow.add(lblInfo, BorderLayout.EAST);

                JPanel bar = new JPanel() {
                    @Override protected void paintComponent(Graphics g) {
                        super.paintComponent(g);
                        Graphics2D g2 = (Graphics2D) g.create();
                        g2.setColor(new Color(0xE2E8F0));
                        g2.fillRoundRect(0, 4, getWidth(), 6, 6, 6);
                        g2.setColor(barColor);
                        g2.fillRoundRect(0, 4, getWidth() * barPct / 100, 6, 6, 6);
                        g2.dispose();
                    }
                };
                bar.setOpaque(false); bar.setPreferredSize(new Dimension(0, 14));

                item.add(nameRow, BorderLayout.NORTH);
                item.add(bar,     BorderLayout.CENTER);
                list.add(item);
            }
        }

        JScrollPane scroll = new JScrollPane(list);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(8);

        card.add(scroll, BorderLayout.CENTER);
        return card;
    }

    // ---- DỊCH VỤ BÁN CHẠY: dùng data thật từ DB ----
    private RoundedPanel buildTopDichVuCard() {
        RoundedPanel card = new RoundedPanel(UIConstants.CARD_RADIUS);
        card.setBackground(Color.WHITE); card.setShadow(true);
        card.setLayout(new BorderLayout());
        card.setBorder(BorderFactory.createEmptyBorder(16,18,16,18));

        JLabel title = new JLabel("Dịch vụ bán chạy");
        title.setFont(UIConstants.FONT_HEADER);
        card.add(title, BorderLayout.NORTH);

        java.util.List<Map<String,Object>> dvList = service.getTopDichVu(5);

        JPanel list = new JPanel();
        list.setOpaque(false);
        list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));

        if (dvList.isEmpty()) {
            JLabel empty = new JLabel("Chưa có dữ liệu dịch vụ");
            empty.setFont(UIConstants.FONT_BODY);
            empty.setForeground(UIConstants.TEXT_MUTED);
            empty.setAlignmentX(Component.CENTER_ALIGNMENT);
            list.add(Box.createVerticalStrut(16));
            list.add(empty);
        } else {
            Color[] dvColors = {UIConstants.PRIMARY, UIConstants.INFO, UIConstants.WARNING,
                                UIConstants.SUCCESS, UIConstants.ORANGE};

            for (int i = 0; i < dvList.size(); i++) {
                Map<String,Object> dv = dvList.get(i);
                String tenDV   = String.valueOf(dv.getOrDefault("tenDV",    ""));
                int    soLan   = dv.containsKey("soLan")   ? (int)  dv.get("soLan")   : 0;
                long   dtDV    = dv.containsKey("doanhThu") ? (long) dv.get("doanhThu") : 0L;

                JPanel item = new JPanel(new BorderLayout());
                item.setOpaque(false);
                item.setBorder(BorderFactory.createEmptyBorder(4,0,4,0));

                final Color c = dvColors[i % dvColors.length];
                JPanel dot = new JPanel() {
                    @Override protected void paintComponent(Graphics g) {
                        Graphics2D g2 = (Graphics2D) g.create();
                        g2.setColor(c); g2.fillOval(0,4,8,8); g2.dispose();
                    }
                };
                dot.setOpaque(false); dot.setPreferredSize(new Dimension(12,16));

                JPanel info = new JPanel();
                info.setOpaque(false);
                info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
                JLabel l1 = new JLabel(tenDV);         l1.setFont(UIConstants.FONT_SMALL_BOLD);
                JLabel l2 = new JLabel(soLan + " lần"); l2.setFont(UIConstants.FONT_SMALL); l2.setForeground(UIConstants.TEXT_MUTED);
                info.add(l1); info.add(l2);

                JLabel lDt = new JLabel(String.format("%,.0fđ", (double) dtDV));
                lDt.setFont(UIConstants.FONT_SMALL_BOLD); lDt.setForeground(UIConstants.PRIMARY);

                JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
                left.setOpaque(false); left.add(dot); left.add(info);
                item.add(left,  BorderLayout.WEST);
                item.add(lDt,   BorderLayout.EAST);
                list.add(item);
            }
        }

        JScrollPane scroll = new JScrollPane(list);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(8);

        card.add(scroll, BorderLayout.CENTER);
        return card;
    }

    // ---- NGUỒN ĐẶT PHÒNG: giữ mock vì DB chưa có bảng này ----
    private RoundedPanel buildNguonDatPhongCard() {
        RoundedPanel card = new RoundedPanel(UIConstants.CARD_RADIUS);
        card.setBackground(Color.WHITE); card.setShadow(true);
        card.setLayout(new BorderLayout());
        card.setBorder(BorderFactory.createEmptyBorder(16,18,16,18));

        JLabel title = new JLabel("Nguồn đặt phòng");
        title.setFont(UIConstants.FONT_HEADER);
        JLabel note = new JLabel("(Demo)");
        note.setFont(UIConstants.FONT_SMALL); note.setForeground(UIConstants.TEXT_MUTED);
        JPanel hdr = new JPanel(new BorderLayout()); hdr.setOpaque(false);
        hdr.add(title, BorderLayout.WEST); hdr.add(note, BorderLayout.EAST);
        card.add(hdr, BorderLayout.NORTH);

        JPanel list = new JPanel();
        list.setOpaque(false);
        list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));

        String[][] nguons = {{"Trực tiếp","38%"},{"Booking.com","28%"},{"Agoda","18%"},{"Airbnb","10%"},{"Khác","6%"}};
        Color[] cs = {UIConstants.PRIMARY, UIConstants.SUCCESS, UIConstants.WARNING, UIConstants.INFO, UIConstants.TEXT_MUTED};

        for (int i = 0; i < nguons.length; i++) {
            final Color barC = cs[i];
            final int pct = Integer.parseInt(nguons[i][1].replace("%",""));
            JPanel item = new JPanel(new BorderLayout(8,0));
            item.setOpaque(false); item.setBorder(BorderFactory.createEmptyBorder(5,0,5,0));
            JLabel lName = new JLabel(nguons[i][0]); lName.setFont(UIConstants.FONT_SMALL);
            lName.setPreferredSize(new Dimension(90,16));
            JPanel bar = new JPanel() {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setColor(new Color(0xE2E8F0));
                    g2.fillRoundRect(0,4,getWidth(),6,6,6);
                    g2.setColor(barC);
                    g2.fillRoundRect(0,4,(int)(getWidth()*pct/100.0),6,6,6);
                    g2.dispose();
                }
            };
            bar.setOpaque(false);
            JLabel lPct = new JLabel(nguons[i][1]); lPct.setFont(UIConstants.FONT_SMALL_BOLD); lPct.setForeground(barC);
            lPct.setPreferredSize(new Dimension(34,16));
            item.add(lName, BorderLayout.WEST); item.add(bar, BorderLayout.CENTER); item.add(lPct, BorderLayout.EAST);
            list.add(item);
        }
        card.add(list, BorderLayout.CENTER);
        return card;
    }

    private void showExportDialog() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JLabel lbTitle = new JLabel("Chọn nội dung muốn xuất:");
        lbTitle.setFont(UIConstants.FONT_BODY_BOLD);
        lbTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(lbTitle);
        panel.add(Box.createVerticalStrut(12));

        JCheckBox chkThongKeKy = new JCheckBox("Thống kê tổng quan (" + getTenKy() + ")");
        JCheckBox chkTheoNgay  = new JCheckBox("Doanh thu theo ngày");
        JCheckBox chkTopPhong  = new JCheckBox("Top phòng doanh thu");
        JCheckBox chkTopDichVu = new JCheckBox("Dịch vụ bán chạy");

        for (JCheckBox cb : new JCheckBox[]{chkThongKeKy, chkTheoNgay, chkTopPhong, chkTopDichVu}) {
            cb.setSelected(true);
            cb.setFont(UIConstants.FONT_BODY);
            cb.setAlignmentX(Component.LEFT_ALIGNMENT);
            panel.add(cb);
            panel.add(Box.createVerticalStrut(6));
        }

        int result = JOptionPane.showConfirmDialog(
            this, panel, "Xuất báo cáo Excel",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result != JOptionPane.OK_OPTION) return;
        if (!chkThongKeKy.isSelected() && !chkTheoNgay.isSelected()
                && !chkTopPhong.isSelected() && !chkTopDichVu.isSelected()) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn ít nhất 1 mục!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Lưu file báo cáo");
        chooser.setSelectedFile(new File("BaoCaoThongKe_" + getTenKy() + "_"
            + new java.text.SimpleDateFormat("yyyyMMdd_HHmm").format(new java.util.Date()) + ".csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

        File file = chooser.getSelectedFile();
        if (!file.getName().toLowerCase().endsWith(".csv"))
            file = new File(file.getAbsolutePath() + ".csv");

        try (java.io.PrintWriter pw = new java.io.PrintWriter(
                new java.io.OutputStreamWriter(new java.io.FileOutputStream(file), "UTF-8"))) {

            pw.write('\ufeff');
            pw.println("BÁO CÁO THỐNG KÊ - " + getTenKy().toUpperCase());
            pw.println("Ngày xuất: " + new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm").format(new java.util.Date()));
            pw.println();

            if (chkThongKeKy.isSelected()) {
                Map<String, Object> stats = service.getThongKeKy(currentKy);
                pw.println("=== THỐNG KÊ TỔNG QUAN ===");
                pw.println("Chỉ tiêu,Giá trị");
                pw.println("Doanh thu,"          + stats.getOrDefault("doanhThu",     0));
                pw.println("Lượt đặt phòng,"     + stats.getOrDefault("luotDatPhong", 0));
                pw.println("Khách mới,"           + stats.getOrDefault("khachMoi",     0));
                pw.println("Doanh thu dịch vụ,"  + stats.getOrDefault("doanhThuDV",   0));
                pw.println();
            }

            if (chkTheoNgay.isSelected()) {
                pw.println("=== DOANH THU THEO NGÀY ===");
                pw.println("Ngày,Doanh thu (VNĐ)");
                long tong = 0;
                for (long[] row : service.getDoanhThuTheoNgay()) {
                    pw.println("Ngày " + row[0] + "," + row[1]);
                    tong += row[1];
                }
                pw.println("Tổng cộng," + tong);
                pw.println();
            }

            if (chkTopPhong.isSelected()) {
                pw.println("=== TOP PHÒNG DOANH THU ===");
                pw.println("STT,Số phòng,Loại phòng,Doanh thu (VNĐ),Lượt thuê");
                int stt = 1;
                for (Map<String, Object> row : service.getTopPhong(10)) {
                    pw.println(stt++ + "," + row.getOrDefault("soPhong","") + ","
                        + row.getOrDefault("tenLoai","") + ","
                        + row.getOrDefault("doanhThu", 0) + ","
                        + row.getOrDefault("luot", 0));
                }
                pw.println();
            }

            if (chkTopDichVu.isSelected()) {
                pw.println("=== DỊCH VỤ BÁN CHẠY ===");
                pw.println("STT,Tên dịch vụ,Số lần dùng,Doanh thu (VNĐ)");
                int stt = 1;
                for (Map<String, Object> row : service.getTopDichVu(10)) {
                    pw.println(stt++ + "," + row.getOrDefault("tenDV","") + ","
                        + row.getOrDefault("soLan", 0) + ","
                        + row.getOrDefault("doanhThu", 0));
                }
            }

            JOptionPane.showMessageDialog(this,
                "✓ Xuất báo cáo thành công!\nFile: " + file.getAbsolutePath(),
                "Thành công", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Lỗi xuất file: " + ex.getMessage(),
                "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String getTenKy() {
        switch (currentKy) {
            case "7ngay": return "7 ngày";
            case "quy":   return "Quý này";
            case "nam":   return "Năm nay";
            default:      return "Tháng này";
        }
    }

    public void refresh() { removeAll(); buildUI(); revalidate(); repaint(); }
}